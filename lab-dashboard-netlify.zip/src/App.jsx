import React from 'react'
import LabDashboard from './LabDashboard.jsx'

export default function App() {
  return <LabDashboard />
}
