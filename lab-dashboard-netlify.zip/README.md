# Lab Dashboard (Vite + React + Tailwind + Recharts)

Este proyecto contiene tu componente `LabDashboard` listo para ejecutar en local y desplegar en Netlify.

## Requisitos
- Node.js 18+
- npm

## Desarrollo local
```bash
npm install
npm run dev
```
Abre el enlace que aparece (por ejemplo `http://localhost:5173`).

## Build de producción
```bash
npm run build
```
La carpeta `dist/` contendrá los archivos estáticos.

## Deploy en Netlify
1. Sube este proyecto a un repositorio (GitHub/GitLab/Bitbucket).
2. En Netlify: **Add new site** → **Import from Git**.
3. Configuración de Build:
   - **Build command:** `npm run build`
   - **Publish directory:** `dist`
4. Deploy.

> Alternativa con arrastrar y soltar: ejecuta `npm run build` y arrastra la carpeta `dist/` a https://app.netlify.com/drop
